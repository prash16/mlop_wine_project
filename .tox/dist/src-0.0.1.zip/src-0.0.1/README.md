Details of the project mlop_wine_project prash m 2021

Steps followed for the project 

1. Create an enviornment 

2. Activate the Enviornments 

3. Create the requirement 

4. Install the requirements
5. Download the data  copy in input data  directory 


#### day 3 

dvc metrics show

tox create a virtual env for you ... testing env for you 



